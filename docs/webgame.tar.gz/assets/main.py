import asyncio

import pygame  # noqa: F401  (pygbag ищет зависимости именно здесь)

import the_snake

asyncio.run(the_snake.main_web())
